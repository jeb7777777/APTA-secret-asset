# side bar menu

A Pen created on CodePen.

Original URL: [https://codepen.io/fghty/pen/NWpeOab](https://codepen.io/fghty/pen/NWpeOab).

